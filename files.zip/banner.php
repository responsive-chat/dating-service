<center>
<div id='google_translate_element'></div>

<script type='text/javascript'>
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'ka', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
}
</script>

<script type='text/javascript' src='//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit'></script>
</center><br>
<center>
<!-- BOOM.GE COUNTER CODE START -->
<script type=text/javascript src="http://links.boom.ge/jc.php?id=61475"></script>
<noscript><a href="http://top.boom.ge/index.php?id=61475" target="_blank"><img src="http://links.boom.ge/nojs.php?id=61475" border="0" alt="BOOM.GE"></a></noscript>
<!-- BOOM.GE COUNTER CODE END -->
</center>