<?exit?>¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦
luka¦¦d740679a12a609b2d1bb2c31de82fe86¦¦male¦¦luka¦¦1041026400¦¦tbilisi¦¦181¦¦77¦¦miriani1987@gmail.com¦¦¦¦598080807¦¦¦¦
*¦¦3208174b330f623ea7ab32616de12c21¦¦male¦¦oto¦¦1473109200¦¦tbilisi¦¦1.75¦¦71¦¦orhanxalilov7@gmail.com¦¦*¦¦555907911¦¦*¦¦
